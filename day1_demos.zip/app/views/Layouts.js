import React, { Component } from 'react';
import { StyleSheet, View, Text } from 'react-native';
import Header from '../sections/Header';
import FlexBasics from '../sections/Layouts/1_FlexBasics';
import FlexDirections from '../sections/Layouts/2_FlexDirections';
import JustifyContent from '../sections/Layouts/3_JustifyContent';
import AlignItems from '../sections/Layouts/4_AlignItems';

class Layouts extends Component {
    static navigationOptions = {
        headerShown: false
    };

    render() {
        return (
            <View style={styles.container}>
                <Header message='Press to Login' />
                {/* <Text style={{ fontSize: 20 }}>This is Layout View</Text> */}
                <FlexBasics />
                {/* <FlexDirections /> */}
                {/* <JustifyContent /> */}
                {/* <AlignItems /> */}
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1
    }
})

export default Layouts;