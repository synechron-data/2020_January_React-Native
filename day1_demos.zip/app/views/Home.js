import React, { Component } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Header from '../sections/Header';
import Picture from '../sections/Picture';
import Menu from '../sections/Menu';

class Home extends Component {
    static navigationOptions = {
        headerShown: false
    };
    
    render() {
        const { navigate } = this.props.navigation;

        return (
            <View style={styles.container}>
                {/* <Text style={{ fontSize: 20, color: 'red' }}>This is my Home View</Text> */}
                <Header message='Press to Login' />
                <Picture />
                <Menu navigate={navigate} />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1
    },
});

export default Home;