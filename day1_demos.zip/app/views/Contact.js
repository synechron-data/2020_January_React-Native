import React, { Component } from 'react';
import { StyleSheet, View, Text, TouchableHighlight, Alert } from 'react-native';
import t from 'tcomb-form-native';
import Header from '../sections/Header';

const User = t.struct({
    name: t.String,
    message: t.String,
    email: t.String,
    active: t.Boolean
});

const options = {
    fields: {
        name: {
            error: 'What should we call you, please give a name'
        },
        message: {
            error: 'Please say something'
        },
        email: {
            error: 'We need email to contact you back.'
        }
    }
};

const Form = t.form.Form;

class Contact extends Component {
    constructor(props) {
        super(props);
    }

    static navigationOptions = {
        headerShown: false
    };

    sendMessage = () => {
        const value = this._form.getValue();

        if (value) {
            // Alert.alert('value: ', value);
            console.log('value: ', value);
            this.props.navigation.goBack();
        }
    }

    clearForm = () => {
        this.setState({ value: null });
    }

    render() {
        return (
            <View style={styles.container}>
                <Header message='Press to Login' />

                <View style={styles.formContainer}>
                    <Form type={User} ref={c => this._form = c} options={options} />

                    <TouchableHighlight style={styles.button} onPress={this.sendMessage} underlayColor='#31e981'>
                        <Text style={styles.buttonText}>
                            Send Message
                    </Text>
                    </TouchableHighlight>

                    <TouchableHighlight style={styles.button} onPress={this.clearForm} underlayColor='#31e981'>
                        <Text style={styles.buttonText}>
                            Reset Form
                    </Text>
                    </TouchableHighlight>
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1
    },
    formContainer: {
        flex: 2,
        padding: 20,
        backgroundColor: '#ffffff'
    },
    buttonText: {
        fontSize: 18,
        color: 'white',
        alignSelf: 'center'
    },
    button: {
        height: 36,
        backgroundColor: '#48BBEC',
        borderColor: '#48BBEC',
        borderWidth: 1,
        borderRadius: 8,
        marginBottom: 10,
        alignSelf: 'stretch',
        justifyContent: 'center'
    }
});

export default Contact;

// import React, { Component } from 'react';
// import { StyleSheet, View, Text, TextInput, TouchableHighlight, Alert } from 'react-native';
// import Header from '../sections/Header';

// class Contact extends Component {
//     constructor(props) {
//         super(props);
//         this.state = {
//             name: '',
//             msg: '',
//             email: '',
//             pin: 0
//         };
//         this.sendMessage = this.sendMessage.bind(this);
//         this.clearForm = this.clearForm.bind(this);
//     }

//     static navigationOptions = {
//         headerShown: false
//     };

//     sendMessage() {
//         Alert.alert(this.state.name, this.state.msg);
//         // console.log(this.props);
//         this.props.navigation.goBack();
//     }

//     clearForm() {
//         this.setState({
//             name: '',
//             msg: '',
//             email: '',
//             pin: 0
//         });
//     }

//     render() {
//         return (
//             <View style={styles.container}>
//                 <Header message='Press to Login' />
//                 <Text style={styles.heading}>Contact Us</Text>

//                 <TextInput style={styles.inputs} placeholder="Enter Name" value={this.state.name}
//                     onChangeText={(text) => this.setState({ name: text })} />

//                 <TextInput style={styles.multiInput} placeholder="Enter Message"
//                     multiline={true}
//                     numberOfLines={4}
//                     value={this.state.msg}
//                     onChangeText={(text) => this.setState({ msg: text })} />

//                 <TextInput style={styles.inputs} placeholder="Enter Email"
//                     value={this.state.email} keyboardType="email-address"
//                     onChangeText={(text) => this.setState({ email: text })} />

//                 <TextInput style={styles.inputs} placeholder="Enter Pin Code"
//                     value={this.state.pin} keyboardType="numeric"
//                     onChangeText={(text) => this.setState({ pin: text })} />

//                 <TouchableHighlight style={styles.buttons} onPress={this.sendMessage} underlayColor='#31e981'>
//                     <Text style={styles.buttonText}>
//                         Send Message
//                     </Text>
//                 </TouchableHighlight>

//                 <TouchableHighlight style={styles.buttons} onPress={this.clearForm} underlayColor='#31e981'>
//                     <Text style={styles.buttonText}>
//                         Reset Form
//                     </Text>
//                 </TouchableHighlight>
//             </View>
//         );
//     }
// }

// const styles = StyleSheet.create({
//     container: {
//         flex: 1,
//         alignItems: 'center',
//         paddingBottom: '45%'
//     },
//     heading: {
//         fontSize: 16,
//         flex: 1
//     },
//     inputs: {
//         flex: 1,
//         width: '90%',
//         borderColor: '#CCCCCC',
//         borderTopWidth: 1,
//         borderBottomWidth: 1,
//         height: 50,
//         fontSize: 20,
//         paddingLeft: 20,
//         paddingRight: 20

//     },
//     multiInput: {
//         flex: 2,
//         width: '90%',
//         borderColor: '#CCCCCC',
//         borderTopWidth: 1,
//         borderBottomWidth: 1,
//         fontSize: 20,
//         paddingLeft: 20,
//         paddingRight: 20
//     },
//     buttons: {
//         borderWidth: 1,
//         borderColor: '#007BFF',
//         backgroundColor: '#007BFF',
//         padding: 15,
//         margin: 5
//     },
//     buttonText: {
//         color: '#FFFFFF',
//         fontSize: 20,
//         textAlign: 'center'
//     }
// })

// export default Contact;