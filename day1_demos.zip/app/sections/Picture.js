import React, { Component } from 'react';
import { StyleSheet, Image } from 'react-native';

class Picture extends Component {
    render() {
        return (
            <Image
                style={styles.mainImage}
                source={require('../../assets/laptop.jpg')} />
        );
    }
}

const styles = StyleSheet.create({
    mainImage: {
        width: undefined,
        height: undefined,
        flex: 3
    }
})

export default Picture;