import React, { Component } from 'react';
import { View, Text, StyleSheet, Image, Alert } from 'react-native';

class Header extends Component {
    constructor(props) {
        super(props);
        this.state = { isLoggedIn: false };
        this.toggleUser = this.toggleUser.bind(this);
    }

    toggleUser() {
        // Alert.alert("Pressed..");
        this.setState(previousState => {
            return { isLoggedIn: !previousState.isLoggedIn };
        });
    }

    render() {
        let displayText = this.state.isLoggedIn ? 'Some User' : this.props.message
        return (
            <View style={styles.headStyle}>
                <Image style={styles.logoStyle}
                    source={require('../../assets/logo.jpg')} />
                <Text style={styles.headText} onPress={this.toggleUser}>{displayText}</Text>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    headStyle: {
        paddingTop: 30,
        paddingRight: 10,
        backgroundColor: '#35605a',
        height: 100,
        flexDirection: 'row',
        borderBottomWidth: 2,
        borderColor: '#000000'
    },
    headText: {
        textAlign: 'right',
        color: '#ffffff',
        fontSize: 20,
        flex: 1
    },
    logoStyle: {
        flex: 1,
        width: undefined,
        height: undefined
    }
});

export default Header;