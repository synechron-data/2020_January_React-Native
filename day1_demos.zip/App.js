// import React from 'react';
// import Home from './app/views/Home';

// export default function App() {
//   return (
//     <Home />
//   );
// }

import React from 'react';
import { createAppContainer } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
import Home from './app/views/Home';
import Layouts from './app/views/Layouts';
import Contact from './app/views/Contact';

const AppNavigator = createStackNavigator({
  HomeRT: {
    screen: Home
  },
  LayoutsRT: {
    screen: Layouts
  },
  ContactRT: {
    screen: Contact
  }
}, {
    initialRouteName: 'HomeRT'
  });

const AppContainer = createAppContainer(AppNavigator);

export default function App() {
  return (
    <AppContainer />
  );
}
