import { AsyncStorage } from 'react-native';
const url = "http://192.168.0.106:8000/api/authenticate";

const authenticator = {
    isAuthenticated: false,

    login(uname, pwd) {
        console.log(uname, pwd);

        var promise = new Promise((resolve, reject) => {
            var data = `username=${uname}&password=${pwd}`;

            let fData = {
                method: "POST",
                headers: {
                    "content-type": "application/x-www-form-urlencoded"
                },
                body: data
            };

            fetch(url, fData).then((response) => {
                response.json().then(async (data) => {
                    if (data.success) {
                        console.log(data.token);
                        await AsyncStorage.setItem('tk', data.token);
                        this.isAuthenticated = data.success;
                        resolve();
                    }
                    else
                        reject(data.message);
                }).catch((err) => {
                    reject("Parsing Error");
                })
            }).catch((err) => {
                reject("Communication Error");
            });
        });

        return promise;
    },

    logout: async function () {
        await AsyncStorage.removeItem('tk');
        this.isAuthenticated = false;
    },

    getToken: async function () {
        const token = await AsyncStorage.getItem('tk');
        console.log("Get: ", token);
        return token;
    }
};

export default authenticator;