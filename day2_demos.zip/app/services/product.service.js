import authenticator from "./authentication.service";

const url = "http://192.168.0.106:8000/api/products";

const productAPIClient = {
    getAllProducts: async function () {
        var tk = await authenticator.getToken();

        var promise = new Promise((resolve, reject) => {


            let fData = {
                method: 'GET',
                headers: {
                    "accept": "application/json",
                    "x-access-token": tk
                }
            };

            fetch(url, fData).then((response) => {
                response.json().then((data) => {
                    if (data.success) {
                        resolve(data.data);
                        console.log(data.data);
                    }
                    else {
                        reject(data.message);
                        console.log(data.message);
                    }
                }).catch((err) => {
                    reject("Parsing Error");
                })
            }).catch((err) => {
                console.log(err);
                reject("Communication Error");
            });
        });

        return promise;
    }
}

export default productAPIClient;