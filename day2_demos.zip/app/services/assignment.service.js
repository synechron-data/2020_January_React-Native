const getUser = function (userId) {
    var promise = new Promise((resolve, reject) => {
        fetch(`https://jsonplaceholder.typicode.com/users/${userId}`).then((response) => {
            response.json().then((data) => {
                resolve(data);
            }).catch((err) => {
                reject("Parsing Error...");
            });
        }).catch((err) => {
            reject("Communication Error...");
        })
    });

    return promise;
}

const getPostsForUser = function (user) {
    var promise = new Promise((resolve, reject) => {
        fetch(`https://jsonplaceholder.typicode.com/posts?userId=${user.id}`).then((response) => {
            var result = response.json();
            result.then(data => {
                user.posts = data;
                resolve(user);
            }).catch(err => {
                reject("JSON Parse Error...");
            })
        }, (err) => {
            reject("Communication Error...");
        });
    });

    return promise;
}

const userAPIClient = {
    getUserWithPost: function (id) {
        return getUser(id).then(getPostsForUser);
    }
};

export default userAPIClient;