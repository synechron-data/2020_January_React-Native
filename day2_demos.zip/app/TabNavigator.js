import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { createBottomTabNavigator } from 'react-navigation-tabs';

class HomeScreen extends React.Component {
    render() {
        return (
            <View style={styles.container}>
                <Text style={{ fontSize: 20 }}>Home Screen</Text>
            </View>
        );
    }
}

class ProfileScreen extends React.Component {
    render() {
        return (
            <View style={styles.container}>
                <Text style={{ fontSize: 20 }}>Profile Screen</Text>
            </View>
        );
    }
}

export default TabNavigator = createBottomTabNavigator({
    Home: HomeScreen,
    Profile: ProfileScreen,
});

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center'
    },
});  