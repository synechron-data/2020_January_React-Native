import React, { Component } from 'react';
import { View, Text, StyleSheet, StatusBar } from 'react-native';
import Header from '../sections/Header';
import AlertDemo from '../sections/Others/AlertDemo';
import ActivityIndicatorDemo from '../sections/Others/ActivityIndicatorDemo';
import PickerDemo from '../sections/Others/PickerDemo';
import ProgressBarDemo from '../sections/Others/ProgressBarDemo';
import SwitchDemo from '../sections/Others/SwitchDemo';

export default class OtherComponents extends Component {
    static navigationOptions = {
        headerShown: false
    };

    constructor(props) {
        super(props);
        this.state = {
        };
    }

    render() {
        return (
            <View style={styles.container}>
                <Header message='Press to Login' />
                {/* <AlertDemo /> */}
                {/* <ActivityIndicatorDemo /> */}
                {/* <StatusBar barStyle="light-content" hidden={true} /> */}
                {/* <PickerDemo /> */}
                {/* <ProgressBarDemo /> */}
                <SwitchDemo />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    }
});
