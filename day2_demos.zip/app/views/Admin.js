import React, { Component } from 'react';
import { View, Text, FlatList, StyleSheet, ActivityIndicator } from 'react-native';

import Header from '../sections/Header';
import productAPIClient from '../services/product.service';
import authenticator from '../services/authentication.service';

function Item({ title }) {
    return (
        <View style={styles.item}>
            <Text style={styles.title}>{title}</Text>
        </View>
    );
}

class Admin extends Component {
    constructor(props) {
        super(props);
        this.state = { products: [], loading: true, message: "Loading Data..." };
    }

    static navigationOptions = {
        headerShown: false
    };

    render() {
        return (
            <View style={styles.container}>
                <Header message='Press to Login' />
                {this.state.message ? <Text style={{ fontSize: 15, color: 'blue' }}>{this.state.message}</Text> : null}
                {this.state.loading ? <ActivityIndicator size='large' /> : null}
                <FlatList
                    data={this.state.products}
                    renderItem={({ item }) => <Item title={item.name} />}
                    keyExtractor={item => item.id.toString()}
                />
            </View>
        );
    }

    componentDidMount() {
        productAPIClient.getAllProducts().then((data) => {
            this.setState({ products: [...data], loading: false, message: "" });
        }).catch((eMsg) => {
            this.setState({ products: [], loading: false, message: eMsg });
        });
    }

    componentWillUnmount(){
        authenticator.logout();
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        paddingBottom: 20
    },
    item: {
        backgroundColor: 'lightblue',
        padding: 20,
        marginVertical: 2,
        marginHorizontal: 15,
    },
    title: {
        fontSize: 20,
    }
})

export default Admin;