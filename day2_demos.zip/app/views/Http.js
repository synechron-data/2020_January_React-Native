import React, { Component } from 'react';
import { StyleSheet, View, Text, ActivityIndicator } from 'react-native';
import Header from '../sections/Header';
import postAPIClient from '../services/post.service';
import { FlatList } from 'react-native-gesture-handler';
import userAPIClient from '../services/assignment.service';

function Item({ title }) {
    return (
        <View style={styles.item}>
            <Text style={styles.title}>{title}</Text>
        </View>
    );
}

class HttpDemo extends Component {
    constructor(props) {
        super(props);
        this.state = { posts: [], loading: true, message: "Loading Data, please wait" };
    }

    static navigationOptions = {
        headerShown: false
    };

    render() {
        return (
            <View style={styles.container}>
                <Header message='Press to Login' />
                {this.state.message ? <Text style={{ fontSize: 20, color: 'blue' }}>{this.state.message}</Text> : null}
                {this.state.loading ? <ActivityIndicator size='large' /> : null}
                <FlatList data={this.state.posts}
                    renderItem={({ item }) => <Item title={item.title} />}
                    keyExtractor={item => item.id.toString()}
                />
            </View>
        );
    }

    componentDidMount() {
        // postAPIClient.getAllPosts().then((data) => {
        //     this.setState({ posts: [...data], loading: false, message: "" });
        // }).catch((eMsg) => {
        //     this.setState({ posts: [], loading: false, message: eMsg });
        // });

        userAPIClient.getUserWithPost(4).then((data) => {
            console.log(data);
        }).catch((eMsg) => {
            console.log(eMsg);
        });
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1
    },
    item: {
        backgroundColor: 'lightblue',
        padding: 20,
        marginVertical: 2,
        marginHorizontal: 15,
    },
    title: {
        fontSize: 20,
    }
})

export default HttpDemo;