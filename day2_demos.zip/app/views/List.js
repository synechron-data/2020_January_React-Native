import React, { Component } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Header from '../sections/Header';
import ScrollViewDemo from '../sections/Lists/ScrollViewDemo';
import FlatListDemo from '../sections/Lists/FlatListDemo';
import SectionListDemo from '../sections/Lists/SectionListDemo';

export default class List extends Component {
    static navigationOptions = {
        headerShown: false
    };

    constructor(props) {
        super(props);
        this.state = {
        };
    }

    render() {
        return (
            <View style={styles.container}>
                <Header message='Press to Login' />
                {/* <ScrollViewDemo /> */}
                {/* <FlatListDemo /> */}
                <SectionListDemo />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    }
});
