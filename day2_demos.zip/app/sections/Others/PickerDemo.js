import React, { Component } from 'react';
import { View, Text, StyleSheet, Picker } from 'react-native';

export default class PickerDemo extends Component {
    constructor(props) {
        super(props);
        this.state = {
            chooseIndex: 0,
            language: "js"
        };
    }

    render() {
        return (
            <View style={styles.container}>
                <Picker style={styles.pickerStyle} selectedValue={this.state.language}
                    onValueChange={(itemValue, itemPosition) => {
                        this.setState({ language: itemValue, chooseIndex: itemPosition })
                    }}>
                    <Picker.Item label="JavaScript" value="js" />
                    <Picker.Item label="React JS" value="react" />
                    <Picker.Item label="Angular" value="ng" />
                    <Picker.Item label="C Sharp" value="cs" />
                </Picker>
                <Text style={styles.textStyle}>{"Index = " + this.state.chooseIndex}</Text>
                <Text style={styles.textStyle}>{"Language = " + this.state.language}</Text>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    textStyle: {
        margin: 24,
        fontSize: 25,
        fontWeight: 'bold',
        textAlign: 'center',
    },
    pickerStyle: {
        height: 150,
        width: "80%",
        color: '#344953',
        justifyContent: 'center',
    }
}) 
