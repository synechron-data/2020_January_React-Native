import React, { Component } from 'react';
import { View, Text, StyleSheet, Button, Alert } from 'react-native';

export default class AlertDemo extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }

    showAlertOne() {
        Alert.alert(
            'Alert One Title',
            'This is the Alert Message',
            [
                {
                    text: 'Cancel',
                    onPress: () => console.log("Cancel Pressed"),
                    style: 'cancel'
                },
                {
                    text: 'OK',
                    onPress: () => console.log("Ok Pressed"),
                }
            ]
        );
    }

    showAlertTwo() {
        Alert.alert(
            'Alert Two Title',
            'This is the Alert Message',
            [
                {
                    text: 'Ask me later',
                    onPress: () => console.log("Ask me later Pressed")
                },
                {
                    text: 'Cancel',
                    onPress: () => console.log("Cancel Pressed"),
                    style: 'cancel'
                },
                {
                    text: 'OK',
                    onPress: () => console.log("Ok Pressed"),
                }
            ],
            { cancelable: false }
        );
    }

    render() {
        return (
            <View style={styles.container}>
                <View style={styles.buttonContainer}>
                    <Button title="Button One" onPress={this.showAlertOne} />
                </View>
                <View style={styles.buttonContainer}>
                    <Button title="Button Two" onPress={this.showAlertTwo} />
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
    },
    buttonContainer: {
        margin: 20
    },
    multiButtonContainer: {
        margin: 20,
        flexDirection: 'row',
        justifyContent: 'space-between'
    }
}) 
