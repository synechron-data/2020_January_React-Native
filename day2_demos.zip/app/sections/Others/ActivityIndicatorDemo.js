import React, { Component } from 'react';
import { View, Text, StyleSheet, ActivityIndicator } from 'react-native';

export default class ActivityIndicatorDemo extends Component {
    constructor(props) {
        super(props);
        this.state = {
            animating: true
        };
        this.closeActivityIndicator = this.closeActivityIndicator.bind(this);
    }

    closeActivityIndicator() {
        setTimeout(() => {
            this.setState({ animating: false })
        }, 5000);
    }

    componentDidMount() {
        this.closeActivityIndicator();
    }

    render() {
        const { animating } = this.state;
        return (
            <View style={[styles.container, styles.horizontal]}>
                <ActivityIndicator animating={animating} size="large" color="red" />
                <ActivityIndicator size="small" />
                <ActivityIndicator size="large" />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center'
    },
    horizontal: {
        flexDirection: 'row',
        justifyContent: 'space-around',
        padding: 10
    }
})  
