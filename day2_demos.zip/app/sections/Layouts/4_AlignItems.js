import React, { Component } from 'react';
import { View, Text, Button } from 'react-native';

class AlignItems extends Component {
    render() {
        return (
            <View style={styles.container}>
                <Text style={styles.headerStyle}>Align Items - Cross Axis</Text>
                {/* <View style={[{ alignItems: 'baseline' }, styles.elementsContainer]}>
                    <View style={{ width: 50, height: 50, backgroundColor: '#EE2C38' }} />
                    <View style={{ width: 50, height: 50, backgroundColor: '#FAA030' }} />
                    <View style={{ width: 50, height: 50, backgroundColor: '#32B76C' }} />
                </View> */}
                {/* <View style={[{ alignItems: 'center' }, styles.elementsContainer]}>
                    <View style={{ width: 50, height: 50, backgroundColor: '#EE2C38' }} />
                    <View style={{ width: 50, height: 50, backgroundColor: '#FAA030' }} />
                    <View style={{ width: 50, height: 50, backgroundColor: '#32B76C' }} />
                </View> */}
                {/* <View style={[{ alignItems: 'flex-start' }, styles.elementsContainer]}>
                    <View style={{ width: 50, height: 50, backgroundColor: '#EE2C38' }} />
                    <View style={{ width: 50, height: 50, backgroundColor: '#FAA030' }} />
                    <View style={{ width: 50, height: 50, backgroundColor: '#32B76C' }} />
                </View> */}
                {/* <View style={[{ alignItems: 'flex-end' }, styles.elementsContainer]}>
                    <View style={{ width: 50, height: 50, backgroundColor: '#EE2C38' }} />
                    <View style={{ width: 50, height: 50, backgroundColor: '#FAA030' }} />
                    <View style={{ width: 50, height: 50, backgroundColor: '#32B76C' }} />
                </View> */}
                <View style={[{ alignItems: 'stretch' }, styles.elementsContainer]}>
                    <View style={{ flex: 1, backgroundColor: '#EE2C38' }} />
                    <View style={{ flex: 1, height: 50, backgroundColor: '#FAA030' }} />
                    <View style={{ flex: 1, height: 50, backgroundColor: '#32B76C' }} />
                </View>
            </View>
        );
    }
}

const styles = {
    container: {
        marginTop: 48,
        flex: 1
    },
    headerStyle: {
        fontSize: 36,
        textAlign: 'center',
        fontWeight: '100',
        marginBottom: 24
    },
    elementsContainer: {
        flex: 1,
        backgroundColor: '#ecf5fd',
    }
}

export default AlignItems;