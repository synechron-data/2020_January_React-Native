import React, { Component } from 'react';
import { View, Text, Button } from 'react-native';

class JustifyContent extends Component {
    render() {
        return (
            <View style={styles.container}>
                <Text style={styles.headerStyle}>Justify Content</Text>
                {/* <View style={[{ justifyContent: 'flex-start' }, styles.elementsContainer]}>
                    <View style={{ width: 50, height: 50, backgroundColor: '#EE2C38' }} />
                    <View style={{ width: 50, height: 50, backgroundColor: '#FAA030' }} />
                    <View style={{ width: 50, height: 50, backgroundColor: '#32B76C' }} />
                </View> */}
                {/* <View style={[{ justifyContent: 'flex-end' }, styles.elementsContainer]}>
                    <View style={{ width: 50, height: 50, backgroundColor: '#EE2C38' }} />
                    <View style={{ width: 50, height: 50, backgroundColor: '#FAA030' }} />
                    <View style={{ width: 50, height: 50, backgroundColor: '#32B76C' }} />
                </View> */}
                {/* <View style={[{ justifyContent: 'center' }, styles.elementsContainer]}>
                    <View style={{ width: 50, height: 50, backgroundColor: '#EE2C38' }} />
                    <View style={{ width: 50, height: 50, backgroundColor: '#FAA030' }} />
                    <View style={{ width: 50, height: 50, backgroundColor: '#32B76C' }} />
                </View> */}
                {/* <View style={[{ justifyContent: 'space-around' }, styles.elementsContainer]}>
                    <View style={{ width: 50, height: 50, backgroundColor: '#EE2C38' }} />
                    <View style={{ width: 50, height: 50, backgroundColor: '#FAA030' }} />
                    <View style={{ width: 50, height: 50, backgroundColor: '#32B76C' }} />
                </View> */}
                {/* <View style={[{ justifyContent: 'space-between' }, styles.elementsContainer]}>
                    <View style={{ width: 50, height: 50, backgroundColor: '#EE2C38' }} />
                    <View style={{ width: 50, height: 50, backgroundColor: '#FAA030' }} />
                    <View style={{ width: 50, height: 50, backgroundColor: '#32B76C' }} />
                </View> */}
                <View style={[{ justifyContent: 'space-evenly' }, styles.elementsContainer]}>
                    <View style={{ width: 50, height: 50, backgroundColor: '#EE2C38' }} />
                    <View style={{ width: 50, height: 50, backgroundColor: '#FAA030' }} />
                    <View style={{ width: 50, height: 50, backgroundColor: '#32B76C' }} />
                </View>
            </View>
        );
    }
}

const styles = {
    container: {
        marginTop: 48,
        flex: 1
    },
    headerStyle: {
        fontSize: 36,
        textAlign: 'center',
        fontWeight: '100',
        marginBottom: 24
    },
    elementsContainer: {
        flex: 1,
        backgroundColor: '#ecf5fd',
    }
}

export default JustifyContent;