import React, { Component } from 'react';
import { View, TouchableOpacity, StyleSheet, Text, Alert } from 'react-native';
import authenticator from '../services/authentication.service';

class Menu extends Component {
    constructor(props) {
        super(props);
        this.onPress = this.onPress.bind(this);
    }

    onPress() {
        Alert.alert("Button Tapped!");
    }

    navigatetoPage(){
        const page = authenticator.isAuthenticated ? 'AdminRT' : 'LoginRT';
        this.props.navigate(page);
    }

    render() {
        return (
            <View style={styles.container}>
                <View style={styles.buttonRow}>
                    <TouchableOpacity style={styles.buttonStyles} onPress={() => this.props.navigate('LayoutsRT')} >
                        <Text style={styles.buttonText}>LAYOUTS</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.buttonStyles} onPress={() => this.props.navigate('ContactRT')}>
                        <Text style={styles.buttonText}>CONTACT FORM</Text>
                    </TouchableOpacity>
                </View>

                <View style={styles.buttonRow}>
                    <TouchableOpacity style={styles.buttonStyles}>
                        <Text style={styles.buttonText} onPress={() => this.props.navigate('ListRT')}>LISTS</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.buttonStyles}>
                        <Text style={styles.buttonText} onPress={() => this.props.navigate('OtherRT')}>OTHERS</Text>
                    </TouchableOpacity>
                </View>

                <View style={styles.buttonRow}>
                    <TouchableOpacity style={styles.buttonStyles}>
                        <Text style={styles.buttonText} onPress={() => this.props.navigate('HttpRT')}>HTTP CALLS</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.buttonStyles}>
                        <Text style={styles.buttonText} onPress={() => this.navigatetoPage()}>ADMIN</Text>
                    </TouchableOpacity>
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 2,
        backgroundColor: '#35605a'
    },
    buttonRow: {
        flex: 2,
        flexDirection: 'row',
        alignItems: 'center',
        borderColor: '#ffffff',
        borderBottomWidth: 1
    },
    buttonStyles: {
        backgroundColor: '#35605a',
        width: '50%',
        height: '50%',
        justifyContent: 'center',
        alignItems: 'center'
    },
    buttonText: {
        color: '#ffffff',
        fontSize: 18
    }
});

export default Menu;