import React, { Component } from 'react';
import { View, Text, StyleSheet, FlatList } from 'react-native';

function Item({ title }) {
    return (
        <View style={styles.item}>
            <Text style={styles.title}>{title}</Text>
        </View>
    );
}

export default class FlatListDemo extends Component {
    constructor(props) {
        super(props);
        this.state = {
            employees: [
                { id: 1, name: "Manish" },
                { id: 2, name: "Abhijeet" },
                { id: 3, name: "Ramakant" },
                { id: 4, name: "Subodh" },
                { id: 5, name: "Abhishek" }
            ]
        };
    }

    render() {
        return (
            <View style={styles.container}>
                <FlatList data={this.state.employees}
                    renderItem={({ item }) => <Item title={item.name} />}
                    keyExtractor={item => item.id.toString()}
                />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1
    },
    item: {
        backgroundColor: 'lightblue',
        padding: 20,
        marginVertical: 2,
        marginHorizontal: 15,
    },
    title: {
        fontSize: 20,
    },
});
