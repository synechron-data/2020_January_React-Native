import React, { Component } from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';

export default class ScrollViewDemo extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }

    render() {
        return (
            <ScrollView style={styles.container}>
                <Text style={{ fontSize: 20 }}>Scroll me plz</Text>
                <View style={styles.boxLarge} />
                <ScrollView horizontal>
                    <View style={styles.boxSmall} />
                    <View style={styles.boxSmall} />
                    <View style={styles.boxSmall} />
                </ScrollView>
                <View style={styles.boxLarge} />
                <View style={styles.boxLarge} />
                <View style={styles.boxLarge} />
            </ScrollView>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    boxSmall: {
        width: 200,
        height: 200,
        marginBottom: 10,
        marginRight: 10,
        backgroundColor: 'skyblue',
    },
    boxLarge: {
        width: 300,
        height: 300,
        marginBottom: 10,
        marginRight: 10,
        backgroundColor: 'steelblue',
    },
})
