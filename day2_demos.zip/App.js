// import React from 'react';
// import Home from './app/views/Home';

// export default function App() {
//   return (
//     <Home />
//   );
// }

import React from 'react';
import { createAppContainer } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
import Home from './app/views/Home';
import Layouts from './app/views/Layouts';
import Contact from './app/views/Contact';
import TabNavigator from './app/TabNavigator';
import List from './app/views/List';
import OtherComponents from './app/views/OtherComponents';
import HttpDemo from './app/views/Http';
import Admin from './app/views/Admin';
import Login from './app/views/Login';

const AppNavigator = createStackNavigator({
  HomeRT: {
    screen: Home
  },
  LayoutsRT: {
    screen: Layouts
  },
  ContactRT: {
    screen: Contact
  },
  ListRT: {
    screen: List
  },
  OtherRT: {
    screen: OtherComponents
  },
  HttpRT: {
    screen: HttpDemo
  },
  AdminRT: {
    screen: Admin
  },
  LoginRT: {
    screen: Login
  }
}, {
  initialRouteName: 'HomeRT'
});

const AppContainer = createAppContainer(AppNavigator);
// const AppContainer = createAppContainer(TabNavigator);

export default function App() {
  return (
    <AppContainer />
  );
}
